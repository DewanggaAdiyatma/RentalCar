<?php

use Illuminate\Support\Facades\Route;
use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('dashboard');
});

//register
Route::get("/register", [RegisterController::class, "registerPage"]);
Route::post("/register", [RegisterController::class, "registerAction"]);

//login
Route::get("/login", [LoginController::class, "loginForm"])
    ->name("login");
Route::post("/login", [LoginController::class, "loginAction"]);
Route::get("/logout", [LoginController::class, "logoutAction"])
    ->name("logout");


//master user
Route::prefix("/master/user")
->middleware(["auth", "admin"])
->group(function() {
    Route::get("/", [UserController::class, "FormList"])
        ->name("user.list");
    Route::view("/add", "master.users.add")
        ->name("user.form-add"); // route get return view
    Route::get("/{user}/edit", [UserController::class, "FormEdit"])
        ->name("user.form-edit"); // route get return view

    Route::post("/add", [UserController::class, "Add"])
        ->name("user.add");
    Route::patch("/{user}/edit", [UserController::class, "Edit"])
        ->name("user.edit"); // route get return view
    Route::delete("/{user}/delete", [UserController::class, "Delete"])
        ->name("user.delete"); // route get return view
});
