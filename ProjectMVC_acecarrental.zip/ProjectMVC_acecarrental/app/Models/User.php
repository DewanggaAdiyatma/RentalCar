<?php

namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Users extends Authenticatable
{
    use HasFactory;

    public $table = "users";
    public $primaryKey = "id";
    public $incrementing = true;

    public $timestamps = false;

    public function getAuthPassword()
    {
        return $this->kata_sandi;
    }
}
