<?php

namespace App\Http\Controllers;

use App\Models\Users;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function FormList()
    {
        $data = Users::query()->get(["id", "username"]);

        return view("master.users.list", [
            "data" => $data
        ]);
    }

    public function Add(Request $request)
    {
        $user = new Users();
        $user->username = $request->input("user");
        $user->password = password_hash($request->input("pass"),
            PASSWORD_DEFAULT);
        $user->save();

        return redirect()->back()
            ->with("success", "Berhasil Tambah Data");
    }

    public function FormEdit($user)
    {
        $data = Users::query()
            ->where("username", "=", $user)
            ->firstOrFail();

        return view("master.users.edit", [
            "d" => $data
        ]);
    }

    public function Edit($user, Request $request)
    {
        $data = Users::query()
            ->where("username", "=", $user)
            ->firstOrFail();

        $data->username = $request->input("user");

        if ($request->input("pass") != null)
            $data->password = password_hash($request->input("pass"), PASSWORD_DEFAULT);

        $data->save();

        return redirect()->to(route("user.list"))
            ->with("success", "Berhasil UPDATE Data");
    }

    public function Delete($user)
    {
        Users::query()
            ->where("username", "=", $user)
            ->delete();

        return redirect()->to(route("user.list"))
            ->with("success", "Berhasil HAPUS Data");
    }
}
