<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function loginForm()
    {
        return view("login");
    }

    public function logoutAction()
    {
        Auth::logout();

        return redirect(route("login"))
            ->with("success", "Terima kasih, sampai jumpa!");
    }

    // Ini sebutan nya adalah dependency Injection
    public function loginAction(Request $request)
    {
        if (Auth::attempt([
            "username" => $request->username,
            "password" => $request->password,
        ]))
        {
            return redirect(route("barang.list"))
                    ->with("success", "Selamat datang admin");
        }
        else
        {
            return redirect()->back()
                ->with("error", "User atau password salah!");
        }
    }
}
