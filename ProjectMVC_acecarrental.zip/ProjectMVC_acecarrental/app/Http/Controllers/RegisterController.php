<?php

namespace App\Http\Controllers;

use App\Models\Users;
use App\Notifications\RegistrationNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;

class RegisterController extends Controller
{
    public function registerPage()
    {
        return view("register.index");
    }

    public function registerAction(Request $request)
    {
        $request->validate([
            "nama" => "required|min:3",
            "alamat" => "required|min:3",
            "notelp" => "required|min:3",
            "noktp" => "required|min:3",
            "username" => "required|min:3",
            "password" => "required|min:3",
            "email" => "required|email"
        ]);

        $u = new Users();
        $u->nama = $request->input("nama");
        $u->alamat = $request->input("alamat");
        $u->notelp = $request->input("notelp");
        $u->noktp = $request->input("noktp");
        $u->username   = $request->input("username");
        $u->kata_sandi = password_hash($request->input("password"), PASSWORD_DEFAULT);
        $u->email      = $request->input("email");
        $u->save();

        // Notifikasi!
        Notification::route("mail", $u->email)
            ->notify(new RegistrationNotification($u->username, $u->email));

        return redirect(route("login"))
            ->with("success", "berhasil daftar! Cek email anda!");
    }
}
