<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class LoginMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // Kalau belum login!
        // if (!$request->session()->has("user"))
        if ($request->session()->has("user") == false)
        {
            return redirect(route("login"))
                    ->with("error", "Anda harus login!");
        }

        // Kalau dah login, ya biarin lanjut!
        return $next($request);
    }
}
