<?php if(session()->has("success")): ?>
<div class="alert alert-success">
    <?php echo e(session()->get("success")); ?>

</div>
<?php endif; ?>
<?php if(session()->has("error")): ?>
<div class="alert alert-danger">
    <?php echo e(session()->get("error")); ?>

</div>
<?php endif; ?>
<?php /**PATH D:\SEMESTER 4\MVC\PROJECT\ProjectMVC-Ace_Rental_Car\ProjectMVC\resources\views/alert.blade.php ENDPATH**/ ?>