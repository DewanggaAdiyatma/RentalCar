<?php $__env->startSection("title", "Dashboard"); ?>

<?php $__env->startSection("body"); ?>

<?php echo $__env->make("alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<nav class="navbar navbar-expand-lg ">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Ace Car Rental</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Product</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Dropdown
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="#">Action</a></li>
              <li><a class="dropdown-item" href="#">Another action</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="#">Something else here</a></li>
            </ul>
          </li>
        </ul>
        <form class="d-flex">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
        <form action="d-flex">
            <button type="button" class="btn btn-dark">Login</button>
        </form>

      </div>
    </div>
  </nav>

  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="images/mobil1.jpg" class="d-block w-100" alt="ini mobil">
        </div>
        <div class="carousel-item">
            <img src="" class="d-block w-100" alt="ini mobil">
        </div>
        <div class="carousel-item">
            <img src="" class="d-block w-100" alt="ini mobil">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<!--container-->
<br>
<div class="container">
    <!--grid-->
    <div class="row">
        <div class="col">
            <center>
                <!--image border-radius-->
                <img width="80%" src="" alt="mobil4" class="rounded-circle">
                <h3>Web Design</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat exercitationem, unde aliquid
                    beatae
                    molestias reiciendis maxime laudantium dolorem ratione atque quibusdam, odio quisquam molestiae
                    voluptas ipsa. Ut adipisci laborum consequuntur.</p>
                <!--button-->
                <a class="btn btn-primary" href="#">Selengkapnya</a>
            </center>
        </div>

        <div class="col">
            <center>
                <!--image border-radius-->
                <img width="80%" src="" alt="mobil5" class="rounded-circle">
                <h3>Web Programming</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat exercitationem, unde aliquid
                    beatae
                    molestias reiciendis maxime laudantium dolorem ratione atque quibusdam, odio quisquam molestiae
                    voluptas ipsa. Ut adipisci laborum consequuntur.</p>
                <!--button-->
                <a class="btn btn-primary" href="#">Selengkapnya</a>
            </center>
        </div>

        <div class="col">
            <center>
                <!--image border-radius-->
                <img width="80%" src="" alt="mobil6" class="rounded-circle">
                <h3>Android Development</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat exercitationem, unde aliquid
                    beatae
                    molestias reiciendis maxime laudantium dolorem ratione atque quibusdam, odio quisquam molestiae
                    voluptas ipsa. Ut adipisci laborum consequuntur.</p>
                <!--button-->
                <a class="btn btn-primary" href="#">Selengkapnya</a>
            </center>
        </div>

    </div>

<!--row untuk membuat media objek-->
<br><br><br>

<div class="row">
    <div class="col-md-7" style="padding: 80px;">
        <h2>avanza</h2>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident, perspiciatis. Mollitia veniam,
            tenetur quisquam eveniet dolor tempore alias maxime praesentium soluta repellendus? Est distinctio
            quos quam fugit, repudiandae doloribus nesciunt.</p>
    </div>
    <div class="col-md-5">
        <img class="img-thumbnail" src="gambar/webdesign.jpg" alt="Web Design">
    </div>
</div>

<hr>

<div class="row">
    <div class="col-md-5">
        <img class="img-thumbnail" src="gambar/webprogramming.jpg" alt="Web Programming">
    </div>
    <div class="col-md-7" style="padding: 80px;">
        <h2>ayla</h2>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident, perspiciatis. Mollitia veniam,
            tenetur quisquam eveniet dolor tempore alias maxime praesentium soluta repellendus? Est distinctio
            quos quam fugit, repudiandae doloribus nesciunt.</p>
    </div>
</div>

<hr>

<div class="row">
    <div class="col-md-7" style="padding: 80px;">
        <h2>inova</h2>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident, perspiciatis. Mollitia veniam,
            tenetur quisquam eveniet dolor tempore alias maxime praesentium soluta repellendus? Est distinctio
            quos quam fugit, repudiandae doloribus nesciunt.</p>
    </div>
    <div class="col-md-5">
        <img class="img-thumbnail" src="gambar/android.jpg" alt="Android Development">
    </div>
</div>


</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 4\MVC\PROJECT\ProjectMVC\resources\views/dashboard.blade.php ENDPATH**/ ?>