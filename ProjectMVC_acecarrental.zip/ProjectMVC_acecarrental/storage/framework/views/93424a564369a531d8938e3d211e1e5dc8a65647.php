<?php $__env->startSection("title", "Dashboard"); ?>

<?php $__env->startSection("body"); ?>
<div class="mt-5"></div>
<?php echo $__env->make("alert", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<nav class="navbar navbar-expand-lg ">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Ace Car Rental</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Product</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Dropdown
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="#">Action</a></li>
              <li><a class="dropdown-item" href="#">Another action</a></li>
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="#">Something else here</a></li>
            </ul>
          </li>
        </ul>
        <form class="d-flex">
          <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
        <form action="d-flex">
            <button type="button" class="btn btn-dark">Login</button>
        </form>

      </div>
    </div>
  </nav>

  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="images/mobil1.jpg" class="d-block w-100" alt="ini mobil">
        </div>
        <div class="carousel-item">
            <img src="" class="d-block w-100" alt="ini mobil">
        </div>
        <div class="carousel-item">
            <img src="" class="d-block w-100" alt="ini mobil">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<!--container-->
<br>
<div class="container">
    <!--grid-->
    <div class="row">
        <div class="col">
            <center>
                <!--image border-radius-->
                <img width="80%" src="" alt="mobil4" class="rounded-circle">
                <h3>Web Design</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat exercitationem, unde aliquid
                    beatae
                    molestias reiciendis maxime laudantium dolorem ratione atque quibusdam, odio quisquam molestiae
                    voluptas ipsa. Ut adipisci laborum consequuntur.</p>
                <!--button-->
                <a class="btn btn-primary" href="#">Selengkapnya</a>
            </center>
        </div>

        <div class="col">
            <center>
                <!--image border-radius-->
                <img width="80%" src="" alt="mobil5" class="rounded-circle">
                <h3>Web Programming</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat exercitationem, unde aliquid
                    beatae
                    molestias reiciendis maxime laudantium dolorem ratione atque quibusdam, odio quisquam molestiae
                    voluptas ipsa. Ut adipisci laborum consequuntur.</p>
                <!--button-->
                <a class="btn btn-primary" href="#">Selengkapnya</a>
            </center>
        </div>

        <div class="col">
            <center>
                <!--image border-radius-->
                <img width="80%" src="" alt="mobil6" class="rounded-circle">
                <h3>Android Development</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat exercitationem, unde aliquid
                    beatae
                    molestias reiciendis maxime laudantium dolorem ratione atque quibusdam, odio quisquam molestiae
                    voluptas ipsa. Ut adipisci laborum consequuntur.</p>
                <!--button-->
                <a class="btn btn-primary" href="#">Selengkapnya</a>
            </center>
        </div>

    </div>

<!--row untuk membuat media objek-->
<br><br><br>

<div class="row">
    <div class="col-md-7" style="padding: 80px;">
        <h2>Avanza</h2>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident, perspiciatis. Mollitia veniam,
            tenetur quisquam eveniet dolor tempore alias maxime praesentium soluta repellendus? Est distinctio
            quos quam fugit, repudiandae doloribus nesciunt.</p>
    </div>
    <div class="col-md-5">
        <img class="img-thumbnail" src="gambar/webdesign.jpg" alt="">
    </div>
</div>

<hr>

<div class="row">
    <div class="col-md-5">
        <img class="img-thumbnail" src="gambar/webprogramming.jpg" alt="">
    </div>
    <div class="col-md-7" style="padding: 80px;">
        <h2>Ayla</h2>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident, perspiciatis. Mollitia veniam,
            tenetur quisquam eveniet dolor tempore alias maxime praesentium soluta repellendus? Est distinctio
            quos quam fugit, repudiandae doloribus nesciunt.</p>
    </div>
</div>

<hr>

<div class="row">
    <div class="col-md-7" style="padding: 80px;">
        <h2>Inova</h2>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Provident, perspiciatis. Mollitia veniam,
            tenetur quisquam eveniet dolor tempore alias maxime praesentium soluta repellendus? Est distinctio
            quos quam fugit, repudiandae doloribus nesciunt.</p>
    </div>
    <div class="col-md-5">
        <img class="img-thumbnail" src="gambar/android.jpg" alt="">
    </div>
</div>

</div>


  <!-- Footer Start -->
  <div class="row container-fluid text-body footer mt-5 pt-5 px-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="container py-5">
        <div class="row g-5">
            <div class="col-lg-3 col-md-6">
                <h3 class="text-light mb-4">Address</h3>
                <p class="mb-2"><i class="fa fa-map-marker-alt text-primary me-3"></i>123 Street, New York, USA</p>
                <p class="mb-2"><i class="fa fa-phone-alt text-primary me-3"></i>+012 345 67890</p>
                <p class="mb-2"><i class="fa fa-envelope text-primary me-3"></i>info@example.com</p>
                <div class="d-flex pt-2">
                    <a class="btn btn-square btn-outline-body me-1" href=""><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-square btn-outline-body me-1" href=""><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-square btn-outline-body me-1" href=""><i class="fab fa-youtube"></i></a>
                    <a class="btn btn-square btn-outline-body me-0" href=""><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <h3 class="text-light mb-4">Services</h3>
                <a class="btn btn-link" href="">Architecture</a>
                <a class="btn btn-link" href="">3D Animation</a>
                <a class="btn btn-link" href="">House Planning</a>
                <a class="btn btn-link" href="">Interior Design</a>
                <a class="btn btn-link" href="">Construction</a>
            </div>
            <div class="col-lg-3 col-md-6">
                <h3 class="text-light mb-4">Quick Links</h3>
                <a class="btn btn-link" href="">About Us</a>
                <a class="btn btn-link" href="">Contact Us</a>
                <a class="btn btn-link" href="">Our Services</a>
                <a class="btn btn-link" href="">Terms & Condition</a>
                <a class="btn btn-link" href="">Support</a>
            </div>
            <div class="col-lg-3 col-md-6">
                <h3 class="text-light mb-4">Newsletter</h3>
                <p>Dolor amet sit justo amet elitr clita ipsum elitr est.</p>
                <div class="position-relative mx-auto" style="max-width: 400px;">
                    <input class="form-control bg-transparent w-100 py-3 ps-4 pe-5" type="text" placeholder="Your email">
                    <button type="button" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button>
                </div>
            </div>
        </div>
    </div>

</div>


  <!-- JavaScript Libraries -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/tempusdominus/js/moment.min.js"></script>
  <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
  <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

  <!-- Template Javascript -->
  <script src="js/main.js"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SEMESTER 4\MVC\PROJECT\ProjectMVC-Ace_Rental_Car\ProjectMVC\resources\views/dashboard.blade.php ENDPATH**/ ?>