@extends("master")

@section("title", "List User")

@section("body")
<div class="mt-5"></div>
@include("alert")
<a href="{{ route("user.form-add") }}" class="btn btn-primary float-end">Tambah User</a>
<table class="table table-default">
<thead>
    <tr>
        <th>ID</th>
        <th>User</th>
        <th>Aksi</th>
    </tr>
</thead>
<tbody>
@foreach ($data as $d)
<tr>
    <td>{{ $d->id }}</td>
    <td>{{ $d->username }}</td>
    <td>
        <a href="{{ url(route("user.form-edit", ["user" => $d->username])) }}"
            class="btn btn-info">Edit</a>
        <form action="{{ url(route("user.delete", ["user" => $d->username])) }}"
            method="post" class="d-inline ml-2" onsubmit="onDelete(event)">
            @csrf
            @method("DELETE")
            <button type="submit" class="btn-danger btn">Delete</button>
        </form>
    </td>
</tr>
@endforeach
</tbody>
</table>

<script>
function onDelete(e)
{
    e.preventDefault();
    let check = confirm("Apakah delete?");
    if (check)
    {
        e.target.submit();
    }
}
</script>
@endsection
