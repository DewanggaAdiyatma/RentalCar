@extends("master")

@section("title", "Add Barang")

@section("body")
@include("alert")
<form action="{{ route("user.add") }}" method="post">
    @csrf
    <div class="form-group">
        <label>Username</label>
        <input type="text" class="form-control" name="user">
    </div>
    <div class="form-group">
        <label>Password</label>
        <input type="password" class="form-control" name="pass">
    </div>
    <button type="submit" class="btn btn-primary">Tambah</button>
    <a href="{{ route('user.list') }}" class="btn btn-secondary">
        Kembali
    </a>
</form>
@endsection
