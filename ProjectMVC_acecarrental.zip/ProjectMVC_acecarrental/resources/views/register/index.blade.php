@extends("master")

@section("title", "Register")

@section("body")
<form action="{{ url("/register") }}" method="post">
@csrf

<x-input-text name="nama" label="nama"></x-input-text>
<x-input-text name="alamat" label="alamat"></x-input-text>
<x-input-text name="noktp" label="noktp"></x-input-text>
<x-input-text name="notelp" label="notelp"></x-input-text>
<x-input-text name="username" label="Username"></x-input-text>
<x-input-text name="password" type="password" label="Password">
</x-input-text>
<x-input-text name="email" label="Email"></x-input-text>
<button type="submit">Register</button>

</form>
@endsection
