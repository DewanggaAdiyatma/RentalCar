@extends('master')

@section('title', 'Dashboard')

@section('body')
    <div class="mt-5"></div>
    @include('alert')

    {{-- Navbar --}}
    <nav class="navbar navbar-expand-lg ">
        <div class="container-fluid">
            <a href="#" class="navbar-brand ms-4 ms-lg-0">
                <h1>Ace Car Rental</h1>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Product</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Dropdown
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                        </ul>
                    </li>
                </ul>
                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
                <form action="d-flex">
                    <button type="button" class="btn btn-dark" scr="{{ url('/login') }}">Login</button>
                </form>

            </div>
        </div>
    </nav>
    {{-- Navbar --}}

    <!--Carousel-->
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                {{-- kalau link yang localhost ngga bs, coba pakai url dibawah ini --}}
                {{-- $url = asset('images/img/mobil1.jpg'); --}}
                <img src="http://localhost:8000/assets/images/img/mobil4-4.jpg" class="d-block w-100" alt="ini mobil">
            </div>
            <div class="carousel-item">
                <img src="http://localhost:8000/assets/images/img/mobil5-5.jpg" class="d-block w-100" alt="ini mobil">
            </div>
            <div class="carousel-item">
                <img src="http://localhost:8000/assets/images/img/mobil3-3.jpg" class="d-block w-100" alt="ini mobil">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>


    <!--container-->
    <br>
    <div class="container">
        <div class="row">
            <div class="col">
                <center>
                    <img width="80%" src="http://localhost:8000/assets/images/img/mobil4.jpg" alt="mobil4"
                        class="rounded-circle">
                    <h3>Kendaraan Serbaguna</h3>
                    <p>Kendarran yang dapat digunakan untuk berpergiaan keluar Kota, Kendaraan ini memiliki ruang kabin yang
                        luas. Biasannya kendaraan jenis ini dapat diisi sampai 8 penumpang. Seperti: Toyota Avanza, Kijang
                        Innova,Toyota Alphard, Daihatsu Xenia, Suzuki Ertiga, Nissan Livina, Honda Mobilio dan sebagainnya.
                    </p>
                </center>
            </div>

            <div class="col">
                <center>
                    <img width="80%" src="http://localhost:8000/assets/images/img/mobil7.png" alt="mobil7"
                        class="rounded-circle">
                    <h3>City Car</h3>
                    <p>Kendaraan yang digunakan untuk berpergian diperkotaan, Kendaraan ini dapat menampung penumpang 4
                        sampai 5 orang. Seperti Toyota Cmary, Toyota Vios, Honda City, Honda Civic, Honda Jazz dan
                        sebagainnya.</p>
                </center>
            </div>

            <div class="col">
                <center>
                    <!--image border-radius-->
                    <img width="80%" src="http://localhost:8000/assets/images/img/mobil8.png" alt="mobil8"
                        class="rounded-circle">
                    <h3>Four Wheel Drive</h3>
                    <p>Kendaraan yang biasanya dilengkapi dengan four wheel drive dengan kemampuan on atau off road.
                        Seperti: Toyota Rush, Honda CRV, Toyota Fortuner, Mitsubhishi Pajero, Ford Ranger dan sebagainnya.
                    </p>
                </center>
            </div>

        </div>
        <!--container-->

        <br><br><br>
        <!-- About Us-->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5">
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                        <div class="about-img">
                            <img class="img-fluid" src="http://localhost:8000/assets/images/img/about-1.jpg"
                                alt="">
                            <img class="img-fluid" src="http://localhost:8000/assets/images/img/about-2.jpg"
                                alt="">
                        </div>
                    </div>
                    <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                        <h4 class="section-title">About Us</h4>
                        <h1 class="display-5 mb-4">persewaan mobil untuk membantu anda berkendara</h1>
                        <p>Layanan rental kendaraan untuk perusahaan maupun personal yang mengutamakan kenyamanan serta
                            keamanan
                            pelanggan.</p>
                        <p class="mb-4">ACE CAR RENTAL menyediakan jasa transportasi dan memberikan solusi paling efisien
                            dan
                            efektif yang mencakup pengelolaan armada untuk meningkatkan efisiensi dalam kegiatan operasional
                            pelanggan.</p>
                        <div class="d-flex align-items-center mb-5">
                            <div class="d-flex flex-shrink-0 align-items-center justify-content-center border border-5 border-primary"
                                style="width: 120px; height: 120px;">
                                <h1 class="display-1 mb-n2" data-toggle="counter-up">5</h1>
                            </div>
                            <div class="ps-4">
                                <h3>Years</h3>
                                <h3>Working</h3>
                                <h3 class="mb-0">Experience</h3>
                            </div>
                        </div>
                        <a class="btn btn-primary py-3 px-5" href="#">Read More</a> {{-- link ke halaman about us --}}
                    </div>
                </div>
            </div>
        </div>
        <!-- About Us-->

        <hr>
        <div class="row">
            <div class="col-md-5">
                <img class="img-thumbnail" src="http://localhost:8000/assets/images/img/mobil4a.jpg" alt="">
            </div>
            <div class="col-md-7" style="padding: 80px;">
                <h2>Toyota Avanza</h2>
                <p>Toyota Avanza adalah mobil yang diproduksi di Indonesia oleh pabrikan Daihatsu, yang dipasarkan juga oleh
                    Daihatsu dengan nama Daihatsu Xenia. Generasi pertama mobil ini diluncurkan pada tanggal 11 Desember
                    2003. Nama "Avanza" berasal dari bahasa Italia dan bahasa Spanyol avanzato/avanza, yang berarti
                    peningkatan.</p>
            </div>
        </div>

        <hr>

        <div class="row">
            <div class="col-md-7" style="padding: 80px;">
                <h2>Daihatsu Ayla</h2>
                <p>Daihatsu Ayla adalah mobil kota (city car) yang dirancang oleh Daihatsu dan diproduksi di Indonesia untuk
                    pasar domestik. Daihatsu merancang dan memproduksi mobil ini, yang kemudian dijual sebagai Daihatsu Ayla
                    dan Toyota Agya</p>
            </div>
            <div class="col-md-5">
                <img class="img-thumbnail" src="http://localhost:8000/assets/images/img/mobil9.jpg" alt="">
            </div>
        </div>

        <hr>

        <div class="row">
            <div class="col-md-5">
                <img class="img-thumbnail" src="http://localhost:8000/assets/images/img/mobil10.jpg" alt="">
            </div>
            <div class="col-md-7" style="padding: 80px;">
                <h2>Toyota Kijang Inova</h2>
                <p>Toyota Kijang Innova adalah sebuah Mobil MPV berukuran menengah buatan Toyota Motor Corporation yang
                    diproduksi di Indonesia oleh Toyota-Astra Motor sejak tahun 2004. Kijang Innova merupakan penerus dari
                    Toyota Kijang, dan diposisikan di atas Toyota Avanza dan Toyota Sienta, dan di bawah Toyota Voxy dan
                    Toyota Alphard di lini kendaraan Toyota Indonesia</p>
            </div>
        </div>
        <hr>
    </div>


    <!-- Feature-->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <h4 class="section-title">Why Choose Us!</h4>
                    <h1 class="display-5 mb-4">Why You Should Trust Us? Learn More About Us!</h1>
                    <p class="mb-4">Rental Kendaraan Kantor Terlengkap
                        telah dipercaya oleh banyak korporasi terkemuka Indonesia untuk urusan kendaraan sewa perusahaan
                        sejak tahun 2018 silam.
                        <br>
                        Komitmen utama kami adalah selalu menyediakan kualitas layanan terbaik dan menjadi "Trusted Partner
                        in Transportation Services."
                    </p>
                    <div class="row g-4">
                        <div class="col-12">
                            <div class="d-flex align-items-start">
                                <img class="flex-shrink-0" src="http://localhost:8000/assets/images/img/icon-1.png"
                                    alt="Icon">
                                <div class="ms-4">
                                    <h3>Jaringan Nasional</h3>
                                    <p class="mb-0"> ACE CAR RENTAL hadir di 10 cabang yang tersebar di seluruh kota
                                        besar di Indonesia.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="d-flex align-items-start">
                                <img class="flex-shrink-0" src="http://localhost:8000/assets/images/img/icon-6.png"
                                    alt="Icon">
                                <div class="ms-4">
                                    <h3>Call Center</h3>
                                    <p class="mb-0">Layanan pelanggan yang siap melayani 24 jam 7 hari seminggu dengan
                                        teknologi berstandar internasional.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="d-flex align-items-start">
                                <img class="flex-shrink-0" src="http://localhost:8000/assets/images/img/icon-3.png"
                                    alt="Icon">
                                <div class="ms-4">
                                    <h3>Applikasi</h3>
                                    <p class="mb-0"> menggunakan SAP (System Application and Processing) yang dapat
                                        memudahkan interaksi dan akses data di seluruh Indonesia secara Real Time.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="feature-img">
                        <img class="img-fluid" src="http://localhost:8000/assets/images/img/about-1.jpg"
                        alt="">
                    <img class="img-fluid" src="http://localhost:8000/assets/images/img/about-2.jpg"
                        alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Feature -->


    <!-- Rent -->
    <div class="container-xxl project py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <h4 class="section-title">Rental Kendaraan</h4>
                <h1 class="display-5 mb-4">Layanan rental kendaraan untuk perusahaan maupun personal yang mengutamakan
                    kenyamanan serta keamanan pelanggan.</h1>
            </div>
            <div class="row g-4 wow fadeInUp" data-wow-delay="0.3s">
                <div class="col-lg-4">
                    <div class="nav nav-pills d-flex justify-content-between w-100 h-100 me-4">
                        <button class="nav-link w-100 d-flex align-items-center text-start p-4 mb-4 active"
                            data-bs-toggle="pill" data-bs-target="#tab-pane-1" type="button">
                            <h3 class="m-0">01. Rental Jangka Panjang</h3>
                        </button>
                        <button class="nav-link w-100 d-flex align-items-center text-start p-4 mb-4" data-bs-toggle="pill"
                            data-bs-target="#tab-pane-2" type="button">
                            <h3 class="m-0">02. Rental Jangka Pendek</h3>
                        </button>
                        <button class="nav-link w-100 d-flex align-items-center text-start p-4 mb-4" data-bs-toggle="pill"
                            data-bs-target="#tab-pane-3" type="button">
                            <h3 class="m-0">03.Car Pooling</h3>
                        </button>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="tab-content w-100">
                        <div class="tab-pane fade show active" id="tab-pane-1">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute img-fluid w-100 h-100"
                                            src="http://localhost:8000/assets/images/img/vertical1.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h1 class="mb-3">Rental Jangka Panjang</h1>
                                    <p class="mb-4">Rental kendaraan dengan durasi mulai dari bulanan hingga tahunan
                                        sesuai kebutuhan perusahaan Anda.</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Harga Lebih Murah</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Hemat Biaya Perawatan</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Terjangkau</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-2">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute img-fluid w-100 h-100"
                                            src="http://localhost:8000/assets/images/img/vertical3.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h1 class="mb-3">Rental Jangka Pendek</h1>
                                    <p class="mb-4">Paket rental yang tepat untuk urusan personal atau keluarga Anda
                                        dengan durasi mulai dari harian hingga mingguan.</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Harga Lebih Murah</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Hemat Biaya Perawatan</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Terjangkau</p>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-3">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute img-fluid w-100 h-100"
                                            src="http://localhost:8000/assets/images/img/vertical2.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h1 class="mb-3">Car Pooling</h1>
                                    <p class="mb-4">Ace Car Rental menawarkan sistem manajemen angkutan bersama atau Car
                                        Pooling yang bisa digunakan oleh karyawan di sebuah perusahaan.</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Harga Lebih Murah</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Hemat Biaya Perawatan</p>
                                    <p><i class="fa fa-check text-primary me-3"></i>Terjangkau</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Rent -->

        <!-- Testimonial -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <h4 class="section-title">Testimonial</h4>
                    <h1 class="display-5 mb-4">Pelanggan Yang Mempercayai Kami Dan Layanan Kami</h1>
                </div>
                <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.1s">
                    <div class="testimonial-item text-center" data-dot="<img class='img-fluid' src='http://localhost:8000/assets/images/img/testimonial-1.jpg' alt=''>">
                        <p class="fs-5">Saya pergi dengan teman-teman kerja saya dan menyewa mobil dari ACE CAR RENTAL,
                            mobilnya bagus, bersih dan mudah sekali untuk menyewannya. Harga juga murah dan terjangkau, ACE
                            CAR
                            RENTAL bakal jadi favorit sewa mobil dikantor saya nih... </p>
                        <h3>Jovana</h3>
                        <span class="text-primary">Manager</span>
                    </div>
                        <div class="testimonial-item text-center" data-dot="<img class='img-fluid' src='http://localhost:8000/assets/images/img/testimonial-2.jpg' alt=''>">
                        <p class="fs-5">Kerenss bingits buat service dr owner dan pegawainya yg very recommended buat low
                            budget yg mo pake rental mobil ke jogja. Mobil selalu bersih, selalu wangi dan pegawai sangat
                            membantu. Pegawainnya juga ramah-ramah, membantu dalam melakukan pemesanan lewat applikasi web
                            yang
                            ada. All thumbs up for ACE CAR RENTAL dan semoga semakin sukses. thx buat ACE CAR RENTAL and
                            teams.
                        </p>
                        <h3>Kevin</h3>
                        <span class="text-primary">Crew</span>
                    </div>
                    <div class="testimonial-item text-center" data-dot="<img class='img-fluid' src='http://localhost:8000/assets/images/img/testimonial-3.jpg' alt=''>">
                        <p class="fs-5">Terimakasih atas persewaan mobil, saya staycation selama 3 hari di jogja tidak ada
                            masalah dengan mobil yang saya pakai untuk pergi ke tempat wisata ..insyaalloh kalau ke jogja lg
                            sy
                            akan hubungi ACE CAR RENTAL …sy ajak rombongan nanti.</p>
                        <h3>Indra</h3>
                        <span class="text-primary">Orang Tua</span>
                    </div>
                </div>
            </div>
        </div>
        <!-- Testimonial-->


    <!--footer dihalaman master-->
    {{--



    <!-- Footer Start -->
    <div class="row container-fluid text-body footer mt-5 pt-5 px-0 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h3 class="text-light mb-4">Address</h3>
                    <p class="mb-2"><i class="fa fa-map-marker-alt text-primary me-3"></i>123 Street, New York, USA</p>
                    <p class="mb-2"><i class="fa fa-phone-alt text-primary me-3"></i>+012 345 67890</p>
                    <p class="mb-2"><i class="fa fa-envelope text-primary me-3"></i>info@example.com</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-square btn-outline-body me-1" href=""><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-square btn-outline-body me-1" href=""><i
                                class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-square btn-outline-body me-1" href=""><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-square btn-outline-body me-0" href=""><i
                                class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h3 class="text-light mb-4">Services</h3>
                    <a class="btn btn-link" href="">Architecture</a>
                    <a class="btn btn-link" href="">3D Animation</a>
                    <a class="btn btn-link" href="">House Planning</a>
                    <a class="btn btn-link" href="">Interior Design</a>
                    <a class="btn btn-link" href="">Construction</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h3 class="text-light mb-4">Quick Links</h3>
                    <a class="btn btn-link" href="">About Us</a>
                    <a class="btn btn-link" href="">Contact Us</a>
                    <a class="btn btn-link" href="">Our Services</a>
                    <a class="btn btn-link" href="">Terms & Condition</a>
                    <a class="btn btn-link" href="">Support</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h3 class="text-light mb-4">Newsletter</h3>
                    <p>Dolor amet sit justo amet elitr clita ipsum elitr est.</p>
                    <div class="position-relative mx-auto" style="max-width: 400px;">
                        <input class="form-control bg-transparent w-100 py-3 ps-4 pe-5" type="text"
                            placeholder="Your email">
                        <button type="button"
                            class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button>
                    </div>
                </div>
            </div>
        </div>

    </div> --}}

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

@endsection
