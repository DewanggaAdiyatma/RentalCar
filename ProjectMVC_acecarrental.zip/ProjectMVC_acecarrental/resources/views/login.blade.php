@extends("master")

@section("title", "Login")

@section("body")
<div class="mt-5"></div>
@include("alert")
<form action="{{ url("/") }}" method="post">
@csrf
<x-input-text name="username" label="Username"></x-input-text>
<x-input-text name="password" label="Password" type="password">
</x-input-text>
<button type="submit" class="btn btn-primary">Login</button>
<a href="{{url("/register")}}">Register</a>
</form>
@endsection

