<div class="form-group mb-2">
    <label>{{ $label ?? $name }}</label>
    <input type="{{ $type ?? 'text' }}"
    class="form-control @error($name) is-invalid @enderror" name="{{ $name }}" value="{{ $value ?? old($name) }}">
    @error($name)
        <div class="bg-danger text-white p-2 mt-1">
            {{ $message }}
        </div>
    @enderror
</div>
