<div class="form-control">
    <label>{{ $label ?? $name }}</label>
    @if ($value == "1")
    <button type="submit" name="{{ $name }}" class="btn btn-danger" value="0">
        Off
    </button>
    @else
    <button type="submit" name="{{ $name }}" class="btn btn-success" value="1">
        On
    </button>
    @endif
</div>
