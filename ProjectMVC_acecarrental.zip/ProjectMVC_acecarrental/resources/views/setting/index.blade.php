@extends("master")

@section("title", "Settings")

@section("body")
<form method="post">
@csrf
<x-toggle :name="'newsletter'" :value="$newsletter" :label="'Status Newsletter'" >
</x-toggle>

<x-toggle :name="'notifikasi'" :value="$notif" :label="'Status Notifikasi'" >
</x-toggle>
</form>
@endsection
